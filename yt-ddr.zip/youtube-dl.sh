#!/bin/bash
echo paste YT link
read ytlink
youtube-dl --extract-audio --audio-format mp3 $ytlink
mv ./*.mp3 ./input
