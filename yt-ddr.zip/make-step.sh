#!/bin/bash
java -jar AutoStepper.jar input="./input/" output="./output" duration=999 hard=true
find ./output -name \*.sm -exec sed -i "s/3333/0000/g" {} \;
