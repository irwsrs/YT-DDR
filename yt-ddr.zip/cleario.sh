#!/bin/bash
rm -r ./input/*
rm -r ./output/*
